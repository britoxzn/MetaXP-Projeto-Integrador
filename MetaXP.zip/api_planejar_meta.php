<?php
header('Content-Type: application/json');

// Pegar os dados enviados pelo JavaScript
$data = json_decode(file_get_contents('php://input'), true);
$titulo = $data['titulo'] ?? '';

if (empty($titulo)) {
    echo json_encode(['success' => false, 'erro' => 'Título não fornecido.']);
    exit;
}

// ⚠️ COLE A SUA NOVA CHAVE DE API AQUI
$api_key = 'AIzaSyC18eD2GqvKg539xXb7z80p_WaTSq3krHM';

// Endpoint do Google para o Gemini
$url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $api_key;

// O comando (prompt) que enviamos para a IA
$prompt = "Atue como um especialista em produtividade. Crie um plano de ação prático e direto para a meta: '$titulo'. Divida em 3 ou 4 passos práticos e fáceis de ler, focados em ação. Use marcadores como '-' ou '*'. Responda apenas com o texto do plano, sem introduções.";

$payload = [
    "contents" => [
        [
            "parts" => [
                ["text" => $prompt]
            ]
        ]
    ]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
// Desativa verificação SSL para evitar erros em servidores gratuitos como o InfinityFree
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

$response = curl_exec($ch);

// ADIÇÃO: Verifica se o servidor conseguiu sequer fazer a conexão
if ($response === false) {
    $erro_curl = curl_error($ch);
    curl_close($ch);
    echo json_encode(['success' => false, 'erro' => 'Falha na conexão do servidor: ' . $erro_curl]);
    exit;
}

$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_status != 200) {
    // Se der erro de API (ex: chave inválida ou cota excedida), mostra o erro
    $erro_detalhe = json_decode($response, true);
    $mensagem = $erro_detalhe['error']['message'] ?? 'Erro desconhecido';
    echo json_encode(['success' => false, 'erro' => "Erro HTTP $http_status: $mensagem"]);
    exit;
}

$result_data = json_decode($response, true);

if (isset($result_data['candidates'][0]['content']['parts'][0]['text'])) {
    $texto_gerado = $result_data['candidates'][0]['content']['parts'][0]['text'];
    echo json_encode(['success' => true, 'plano' => trim($texto_gerado)]);
} else {
    echo json_encode(['success' => false, 'erro' => 'A IA não retornou um formato válido.']);
}
<?php
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$nome = $input['nome'] ?? 'Guerreiro(a)';

$apiKey = 'AIzaSyC18eD2GqvKg539xXb7z80p_WaTSq3krHM';

// Alterado para gemini-1.5-flash que é a versão estável atual
$url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $apiKey;

$prompt = "Você é um treinador pessoal super empolgante em um app de metas gamificado. Escreva uma mensagem motivacional muito curta (máximo de 2 frases) para o usuário chamado {$nome}. Incentive-o a completar as metas de hoje para ganhar mais XP e subir de nível. Use um tom direto, inspirador e inclua até 1 emojis. Não use aspas.";

$data = [
    'contents' => [
        [
            'parts' => [
                ['text' => $prompt]
            ]
        ]
    ]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
    $mensagem = trim($result['candidates'][0]['content']['parts'][0]['text']);
    // Chave alterada para 'sugestao' para bater com o seu JavaScript
    echo json_encode(['success' => true, 'sugestao' => htmlspecialchars($mensagem)]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro na API.']);
}
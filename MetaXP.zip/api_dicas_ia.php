<?php
// Define que o retorno será em JSON
header('Content-Type: application/json');

// Recebe os dados enviados pelo JavaScript (o título da meta)
$input = json_decode(file_get_contents('php://input'), true);
$metaTitulo = $input['meta'] ?? '';

// Se não tiver título, retorna erro
if (empty($metaTitulo)) {
    echo json_encode(['success' => false, 'message' => 'Nenhuma meta foi enviada.']);
    exit;
}

// ==========================================
// 🔑 COLE SUA CHAVE DE API AQUI ENTRE AS ASPAS
$apiKey = 'AIzaSyC18eD2GqvKg539xXb7z80p_WaTSq3krHM';
// ==========================================

// Endpoint oficial atualizado para o Gemini 2.5 Flash
$url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $apiKey;

// O que vamos pedir para a IA
$prompt = "Dê uma dica muito curta e prática (máximo de 2 frases) de como dar o primeiro passo para alcançar a seguinte meta: " . $metaTitulo;

// Monta a estrutura que o Google exige
$data = [
    'contents' => [
        [
            'parts' => [
                ['text' => $prompt]
            ]
        ]
    ]
];

// Inicia a conexão com o cURL
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

// 🚨 SALVA-VIDAS DA INFINITYFREE: Desativa a verificação de SSL para evitar bloqueios
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

// Executa e pega a resposta
$response = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

// Se o servidor bloquear a conexão totalmente
if ($err) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão no servidor: ' . $err]);
    exit;
}

// Decodifica a resposta do Google
$result = json_decode($response, true);

// Verifica se a resposta veio com o texto certinho
if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
    $dica = $result['candidates'][0]['content']['parts'][0]['text'];
    echo json_encode(['success' => true, 'dica' => nl2br(htmlspecialchars($dica))]);
} else {
    // Se o Google reclamar da chave ou de outra coisa, mostra o erro exato
    $errorMsg = $result['error']['message'] ?? 'Resposta inesperada da API.';
    echo json_encode(['success' => false, 'message' => 'Erro do Google: ' . $errorMsg]);
}
?>